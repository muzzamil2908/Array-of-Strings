/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assignment14;
import java.util.Scanner;

public class Assignment14 {

    public static void main(String[] args)
    {
    int StudentCount;
    int SubjectCount ,i,j;
    Scanner keyboard = new Scanner(System.in);
    System.out.print("hello user ");
    System.out.print("how many students.(rows).? ");
    StudentCount= keyboard.nextInt();
    System.out.print("how many students.(columns).? ");
    SubjectCount= keyboard.nextInt();
    
    
    
    int [][] mark;
        mark = new int[StudentCount][SubjectCount];
    
    
    for(i=0;i<StudentCount;i++)
        {
    System.out.println( "Student "+(i+1));
    for(j=0;j<SubjectCount;j++)
            {
         System.out.print("mark "+(j+1)+ ":");
         mark[i][j]=keyboard.nextInt();
             }
    }
    
    // lets loop to print table
    
    for(i=0;i<StudentCount;i++)
    {
        //line
    for(j=0;j<SubjectCount;j++)
    {
    System.out.print("|-----");
    }
    System.out.println("|");
    
    // marks
    for(j=0;j<SubjectCount;j++)
    {
    System.out.print(String.format("| %3d ", mark[i][j]));
    
    }
    System.out.println("|");
    
    }
    System.out.print("|-----");
    System.out.print("|");
    System.out.print("|-----");
    System.out.println("|");
    }
    
}
